"""3D PINN for Helmholtz equation on unit cube."""

__version__ = "0.1.0"
